## Getting Started


## Project Structure

```
.
 ├── resources                    # Build files on the specific platforms (iOS, Android) and app icon + splash
 ├── src                          # This is where the app lives - *the main folder*
 ├── .editorconfig                # A helper file to define and maintain coding styles across environments
 ├── .gitignore                   # Specifies intentionally untracked files to ignore when using Git
 ├── .io-config.json              # Ionic ID
 ├── config.xml                   # Ionic config file
 ├── .ionic.config.json           # Global configuration for your Ionic app
 ├── package.json                 # Dependencies and build scripts
 ├── readme.md                    # Project description
 ├── tsconfig.json                # TypeScript configurations
 └── tslint.json                  # TypeScript linting options
```



### src directory
```
.
   ├── ...
   ├── src                       
   │   ├── app                    # This folder contains global modules and styling
   │   ├── assets                 # This folder contains images and the *data.json*
   |   ├── component              # This folder contains compoent 
   |   ├── core                   # This folder contains services  
   |   ├── pages                  # Contains all the individual pages (home, tabs, category, list single-item)
   |   ├── services               # Contains the item-api service that retrieves data from the JSON file
   |   ├──shared                  # Contains the item-api service that retrieves data from the JSON file
   |   ├── theme                  # The global SCSS variables to use throughout the app
   |   ├── declarations.d.ts      # A config file to make TypeScript objects available in intellisense
   |   ├── index.html             # The root index app file - This launches the app
   |   ├── manifest.json          # Metadata for the app
   │   └── service-worker.js      # Cache configurations
   └── ...
```




## Start the project
The project is started with the regular ionic commands.

1. Run `npm install` to install all dependencies.
2. Run `ionic serve` to start the development environment.
3. To build the project run `ionic build android` or `ionic build ios`. In order for you to build an iOS app, you need to run on MacOS.

An alternative is to emulate the app on a device or upload it to the ionic cloud. From here you can download the ionic view app and use the app on all devices.



## FLOW OF PROJECT
The project is started from root page 

1. first page is `FIRST_PAGE`  --->



## MODULE WAISE FLOW


## Bugs and Issues

Have a bug or an issue with this template? 


## Creator

The template was created by and is maintained by **[Virtual  Galaxy]**



## Copyright and License

Copyright 2018 vIRTUAL Galaxy infotech pvt. Ltd . Code released under the [VIRTUAL]() license.


**RTGS/NEFT/OWN/OTHER/ALL TYPE FUNDTRANSFER**

+i in this page constructor is call +i 
1) using navParams get bank detail Array (BankArray);
2) using localstrage get user Detail to it(loginUserInfo);

a)ionViewDidLoad()  call after constructor 

b)Get_AccountDetails( ) using this get account detail on page. with parameters and call api                     /api/virtualpay/Get_Account" to show account list on dropdown.
 
 c)FromAccountchange()
  using  this method we select From account Detail.

 d)ToAccountDetail() 
using this get account detail on page. with parameters and call api                     /api/virtualpay/Get_Account" to show account list on dropdown.

e)ToAccountchange()
 using  this method we select To account Detail.

f) submit() 
 1)first call ValidateData()
 This method use to check undefind variable or null variable value.

 2)using submit method call for OTP api  "/api/virtualpay/GetTranOTPRequest"
on that success we show insert otp section ,call OTP_Process() on success.

g) OTP_Process() 
this method use to process to check otp and user detail .and call back method "Callback_Clear()"
and show success message on TRAN_VIEW_dETAIL page .

h) Callback_Clear()
this method use to clean all input fiels on page and after that show message to model box "TRAN_VIEW_dETAIL"