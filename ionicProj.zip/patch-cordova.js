const fs = require('fs-extra');
const path = require('path');

const source = path.join(__dirname, 'src', 'assets');
const destination = path.join(__dirname, 'www', 'assets');

try {
  fs.copySync(source, destination, {
    overwrite: true,
    filter: (src, dest) => {
      // Skip any file named vssver2.scc (case-insensitive)
      if (path.basename(src).toLowerCase() === 'vssver2.scc') {
        console.log('⏭️ Skipping file:', src);
        return false;
      }
      return true; // copy everything else
    }
  });
  console.log('✅ Files copied successfully (excluding vssver2.scc)!');
} catch (err) {
  console.error('❌ Error while copying files:', err);
}
