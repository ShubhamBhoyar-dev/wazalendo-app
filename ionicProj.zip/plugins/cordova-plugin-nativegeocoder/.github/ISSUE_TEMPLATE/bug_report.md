---
name: Bug report
about: Create a report to help us improve

---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Plugin Version**
vX.X.X

**Smartphone (please complete the following information):**
 - Device: [e.g. iPhone6] or Emulator: [e.g. Nexus 7]
 - OS: [e.g. iOS8.1]

**Additional context**
Add any other context about the problem here.
