module.exports = {
    // UglifyJS configuration options
    mangle: {
        reserved: ['List', 'of', 'global', 'variable', 'names']
    },
    compress: true,
    output: {
        comments: false
    }
};
 