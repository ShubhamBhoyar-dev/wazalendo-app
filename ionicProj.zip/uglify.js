const fs = require('fs');
const path = require('path');
const uglifyjs = require('uglify-js');
const { execSync } = require('child_process');
const path = require('path');

// Path to the Android project directory
const androidProjectDir = 'platforms/android';

// Path to the ProGuard configuration file
const proguardConfigFile = 'proguard-rules.pro'; // Update this to your ProGuard config file if needed

// Path to the directory containing Java files (src directory within Android project)
const javaDirectory = path.join(androidProjectDir, 'app', 'src', 'main', 'java');


// Run ProGuard for obfuscating Java files
function obfuscateJavaFiles() {
    try {
      // Command to run ProGuard for Java obfuscation
      const proguardCommand = `cd ${androidProjectDir} && ./gradlew app:proguardRelease --no-daemon`;
  
      // Execute ProGuard command
      execSync(proguardCommand, { stdio: 'inherit' });
      
      console.log('Java files obfuscated successfully.');
    } catch (error) {
      console.error('Error during Java obfuscation:', error);
    }
  }

// Function to obfuscate a single file
function obfuscateFile(filePath) {
  const code = fs.readFileSync(filePath, 'utf8');
  const obfuscatedCode = uglifyjs.minify(code);
  
  if (obfuscatedCode.error) {
    console.error(`Error obfuscating ${filePath}: ${obfuscatedCode.error}`);
    return;
  }

  fs.writeFileSync(filePath, obfuscatedCode.code, 'utf8');
  console.log(`Obfuscated ${filePath}`);
}

// Function to obfuscate all JavaScript files in a directory recursively
function obfuscateDirectory(dirPath) {
  const files = fs.readdirSync(dirPath);
  
  files.forEach(file => {
    const filePath = path.join(dirPath, file);
    const stat = fs.statSync(filePath);
    if (stat.isDirectory()) {
        obfuscateDirectory(filePath); // Recursive call for directories
      } else if (file.endsWith('.js') || file.endsWith('.ts')) {
        obfuscateFile(filePath); // Obfuscate JavaScript/TypeScript files
      }
    
  });
}

// Specify the directory containing your JavaScript files
const directoryToObfuscate = 'src'; // Change this to your directory path

// Start obfuscation process
obfuscateDirectory(directoryToObfuscate);
obfuscateJavaFiles();
